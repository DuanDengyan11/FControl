using Pkg
Pkg.add(PackageSpec(url="https://github.com/RoboticExplorationLab/MatrixCalculus.jl.git"))
